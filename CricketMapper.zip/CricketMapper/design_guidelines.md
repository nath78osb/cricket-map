# Cricket Match Map - Design Guidelines

## Design Approach
**Material Design System** - Selected for its robust handling of information density, excellent mobile-first patterns, and proven map integration patterns. Material's elevation system and card components align perfectly with the interactive map + popup card interaction model.

## Core Design Principles
1. **Map-First Interface** - The map is the primary navigation tool, not a supplementary feature
2. **Information Clarity** - Cricket scores must be instantly readable across multiple formats
3. **Touch-Optimized** - All interactions designed for mobile fingers, not mouse cursors
4. **Progressive Disclosure** - Show essential info on markers, full details in popups

## Layout System

**Spacing Scale**: Tailwind units of **2, 4, 8, 12, 16** for consistent rhythm
- Tight spacing (p-2, gap-2): Within compact elements like filter chips
- Standard spacing (p-4, gap-4): Card content, button padding
- Generous spacing (p-8, gap-8): Section separation, modal padding
- Large spacing (p-12, p-16): Major layout divisions

**Layout Structure**:
- Full viewport height map (100vh minus header)
- Persistent filter panel: Collapsible drawer on mobile, fixed sidebar on desktop (320px width)
- Map controls: Bottom-right corner (zoom, geolocation, layer toggle)
- Match popup cards: Centered overlay on mobile, positioned near marker on desktop

## Typography Hierarchy

**Font Family**: 
- Primary: Inter (via Google Fonts) - clean, highly legible for data display
- Monospace: Roboto Mono - for score displays and match timing

**Type Scale**:
- Page Title: text-2xl font-bold (filter panel header)
- Match Team Names: text-lg font-semibold
- Score Display: text-3xl font-bold (monospace) - dominant visual element
- Match Details: text-sm - over status, venue, time
- Filter Labels: text-xs font-medium uppercase tracking-wide
- Body Text: text-base - descriptive content

## Component Library

### Map Interface
- **Cluster Markers**: Grouped pins showing count when multiple matches in proximity
- **Individual Markers**: Pin-style markers with sport icon, color-coded by match status (live/upcoming/completed)
- **Interactive States**: Hover scale (1.1x), active pulse animation for live matches
- **Map Style**: Clean, minimal basemap emphasizing locations over terrain

### Match Popup Card
- **Card Structure**: Rounded-2xl corners, elevated shadow (shadow-2xl)
- **Max Width**: 420px on desktop, 90vw on mobile with 16px margins
- **Sections**:
  - Header: Team names (text-lg font-semibold), league badge/icon
  - Score Display: Prominent center-aligned scores in monospace font
  - Match Format Indicator: Chip/badge showing "Limited Overs", "Test Match", etc.
  - Details Grid: 2-column layout for venue, time, overs (if applicable)
  - Action Footer: "View Full Scorecard" link, share icon
- **Score Format Examples**:
  - Limited Overs: "332-10 (50 ov)" vs "122-7 (28.4 ov)"
  - Test/Long Format: "500-2 dec & 200-10" vs "322-5"
- **Overflow Behavior**: Max height 80vh with scroll for extensive details

### Filter Panel
- **Desktop**: Fixed left sidebar (320px), persistent visibility
- **Mobile**: Bottom sheet drawer, swipe-up to expand, backdrop overlay when open
- **Filter Categories**:
  - Data Source Toggle: Segmented button (Play Cricket UK / PlayHQ / ESPNcricinfo)
  - League/Competition: Searchable dropdown with autocomplete
  - Club: Multi-select with checkboxes, search input
  - Player: Search input with suggestion dropdown
  - Match Status: Chip toggles (Live / Upcoming / Completed)
- **Interactions**: Apply button at bottom, Clear All link at top
- **Active Filters**: Chip display below search bar showing applied filters with X to remove

### Navigation Header
- **Height**: 64px (h-16)
- **Contents**: 
  - Left: App logo/icon + "Cricket Map" title
  - Right: Settings icon, user profile (if auth implemented)
- **Mobile**: Hamburger menu icon to open filter drawer
- **Sticky**: Fixed position at top (z-50)

### Data Cards (Match List View - Secondary)
- **Alternative View**: Toggle between Map View and List View
- **List Items**: Card format with left accent border indicating match status
- **Content**: Team names, score summary, venue, time, tap to center map on location

## Touch & Interaction Patterns

**Touch Targets**: Minimum 44px × 44px for all interactive elements
**Gestures**:
- Map: Pinch zoom, two-finger pan, double-tap zoom
- Filter Drawer: Swipe up/down to expand/collapse
- Match Cards: Tap marker → card appears, tap outside → dismisses
- Filters: Tap chips to toggle, tap dropdown to expand

**Loading States**:
- Map: Skeleton screen with gray placeholder tiles
- Markers: Progressive load with fade-in (stagger 50ms intervals)
- Scores: Shimmer effect while fetching updates

**Empty States**:
- No matches found: Illustration + "No matches in this area" message + "Clear Filters" button
- No filter results: "Try adjusting your filters" with quick reset options

## Responsive Breakpoints

- **Mobile**: < 768px - Single column, bottom drawer, full-width cards
- **Tablet**: 768px - 1024px - Map + collapsible sidebar, wider cards
- **Desktop**: > 1024px - Map + persistent sidebar, positioned popups

## Animation Guidelines
**Minimal & Purposeful** - Use sparingly for:
- Live match pulse: Subtle 2s infinite pulse on active match markers
- Card entry: Slide up + fade in (200ms ease-out)
- Filter drawer: Slide transition (300ms ease-in-out)
- Score updates: Brief highlight flash when number changes (500ms)

**Avoid**: Excessive hover effects, parallax, continuous animations

## Accessibility
- ARIA labels on all map markers ("Live match: Team A vs Team B at Venue")
- Keyboard navigation: Tab through filters, Enter to select, Escape to close modals
- Focus indicators: 2px outline on all interactive elements
- Screen reader announcements for score updates
- Color-independent status indicators (icons + text, not color alone)

## Images
**No hero image** - This is a utility app where the map IS the hero element. The full-viewport map serves as the primary visual.

**Supporting Images**:
- Team logos/crests: 32px × 32px in match cards, loaded from API or placeholder
- League badges: 24px × 24px in filter sections and card headers
- Empty state illustrations: 240px × 200px centered SVG graphics

## Data Display Patterns
**Score Formatting**:
- Use monospace font for alignment
- Wickets in superscript when appropriate
- Overs in parentheses, grayed out (text-gray-600)
- Declared innings: "dec" suffix
- Follow-on indicators: Second innings in stacked format

**Real-time Updates**:
- Polling interval: 30 seconds for live matches
- Visual indicator: Small pulsing dot next to "LIVE" badge
- Update animation: Number morphs with brief highlight

This design creates a professional, data-focused cricket tracking experience optimized for mobile discovery while maintaining desktop usability. The Material Design foundation ensures consistency, accessibility, and proven patterns for map-based applications.