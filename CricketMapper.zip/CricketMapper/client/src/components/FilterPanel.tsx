import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Search, X, Filter } from "lucide-react";

export interface FilterState {
  dataSource: string;
  league: string;
  clubs: string[];
  player: string;
  statuses: string[];
}

interface FilterPanelProps {
  onFilterChange?: (filters: FilterState) => void;
  className?: string;
}

export default function FilterPanel({ onFilterChange, className }: FilterPanelProps) {
  const [filters, setFilters] = useState<FilterState>({
    dataSource: "all",
    league: "",
    clubs: [],
    player: "",
    statuses: ["live"],
  });

  const dataSources = [
    { value: "all", label: "All Sources" },
    { value: "playcricket", label: "Play Cricket UK" },
    { value: "playhq", label: "PlayHQ Australia" },
    { value: "espn", label: "ESPNcricinfo" },
  ];

  const mockLeagues = [
    "IPL 2024",
    "County Championship",
    "Big Bash League",
    "The Hundred",
  ];

  const mockClubs = [
    "Mumbai Indians",
    "Chennai Super Kings",
    "Yorkshire CCC",
    "Lancashire CCC",
  ];

  const matchStatuses = ["live", "upcoming", "completed"];

  const toggleStatus = (status: string) => {
    const newStatuses = filters.statuses.includes(status)
      ? filters.statuses.filter((s) => s !== status)
      : [...filters.statuses, status];
    
    const newFilters = { ...filters, statuses: newStatuses };
    setFilters(newFilters);
    onFilterChange?.(newFilters);
  };

  const toggleClub = (club: string) => {
    const newClubs = filters.clubs.includes(club)
      ? filters.clubs.filter((c) => c !== club)
      : [...filters.clubs, club];
    
    const newFilters = { ...filters, clubs: newClubs };
    setFilters(newFilters);
    onFilterChange?.(newFilters);
  };

  const clearFilters = () => {
    const newFilters: FilterState = {
      dataSource: "all",
      league: "",
      clubs: [],
      player: "",
      statuses: [],
    };
    setFilters(newFilters);
    onFilterChange?.(newFilters);
  };

  const activeFilterCount =
    (filters.league ? 1 : 0) +
    filters.clubs.length +
    (filters.player ? 1 : 0) +
    filters.statuses.length +
    (filters.dataSource !== "all" ? 1 : 0);

  return (
    <div className={`flex flex-col h-full bg-sidebar ${className}`}>
      <div className="p-4 border-b border-sidebar-border">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <Filter className="w-5 h-5" />
            Filters
          </h2>
          {activeFilterCount > 0 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={clearFilters}
              data-testid="button-clear-filters"
            >
              Clear All
            </Button>
          )}
        </div>
        
        {activeFilterCount > 0 && (
          <div className="flex flex-wrap gap-2" data-testid="container-active-filters">
            {filters.dataSource !== "all" && (
              <Badge variant="secondary">
                {dataSources.find((d) => d.value === filters.dataSource)?.label}
                <X
                  className="w-3 h-3 ml-1 cursor-pointer"
                  onClick={() => {
                    const newFilters = { ...filters, dataSource: "all" };
                    setFilters(newFilters);
                    onFilterChange?.(newFilters);
                  }}
                />
              </Badge>
            )}
            {filters.league && (
              <Badge variant="secondary">
                {filters.league}
                <X
                  className="w-3 h-3 ml-1 cursor-pointer"
                  onClick={() => {
                    const newFilters = { ...filters, league: "" };
                    setFilters(newFilters);
                    onFilterChange?.(newFilters);
                  }}
                />
              </Badge>
            )}
            {filters.clubs.map((club) => (
              <Badge key={club} variant="secondary">
                {club}
                <X
                  className="w-3 h-3 ml-1 cursor-pointer"
                  onClick={() => toggleClub(club)}
                />
              </Badge>
            ))}
          </div>
        )}
      </div>

      <ScrollArea className="flex-1">
        <div className="p-4 space-y-6">
          <div className="space-y-2">
            <Label className="text-xs font-medium uppercase tracking-wide">
              Data Source
            </Label>
            <Select
              value={filters.dataSource}
              onValueChange={(value) => {
                const newFilters = { ...filters, dataSource: value };
                setFilters(newFilters);
                onFilterChange?.(newFilters);
              }}
            >
              <SelectTrigger data-testid="select-data-source">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {dataSources.map((source) => (
                  <SelectItem key={source.value} value={source.value}>
                    {source.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label className="text-xs font-medium uppercase tracking-wide">
              Match Status
            </Label>
            <div className="flex flex-wrap gap-2">
              {matchStatuses.map((status) => (
                <Badge
                  key={status}
                  variant={filters.statuses.includes(status) ? "default" : "outline"}
                  className="cursor-pointer"
                  onClick={() => toggleStatus(status)}
                  data-testid={`badge-status-filter-${status}`}
                >
                  {status.toUpperCase()}
                </Badge>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Label className="text-xs font-medium uppercase tracking-wide">
              League / Competition
            </Label>
            <Select
              value={filters.league || "all"}
              onValueChange={(value) => {
                const newFilters = { ...filters, league: value === "all" ? "" : value };
                setFilters(newFilters);
                onFilterChange?.(newFilters);
              }}
            >
              <SelectTrigger data-testid="select-league">
                <SelectValue placeholder="All Leagues" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Leagues</SelectItem>
                {mockLeagues.map((league) => (
                  <SelectItem key={league} value={league}>
                    {league}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label className="text-xs font-medium uppercase tracking-wide">
              Clubs
            </Label>
            <div className="space-y-2">
              {mockClubs.map((club) => (
                <div key={club} className="flex items-center space-x-2">
                  <Checkbox
                    id={club}
                    checked={filters.clubs.includes(club)}
                    onCheckedChange={() => toggleClub(club)}
                    data-testid={`checkbox-club-${club}`}
                  />
                  <label
                    htmlFor={club}
                    className="text-sm cursor-pointer flex-1"
                  >
                    {club}
                  </label>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="player-search" className="text-xs font-medium uppercase tracking-wide">
              Player Search
            </Label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                id="player-search"
                placeholder="Search player name..."
                value={filters.player}
                onChange={(e) => {
                  const newFilters = { ...filters, player: e.target.value };
                  setFilters(newFilters);
                  onFilterChange?.(newFilters);
                }}
                className="pl-9"
                data-testid="input-player-search"
              />
            </div>
          </div>
        </div>
      </ScrollArea>

      <div className="p-4 border-t border-sidebar-border">
        <Button
          className="w-full"
          onClick={() => {
            console.log('Apply filters:', filters);
            onFilterChange?.(filters);
          }}
          data-testid="button-apply-filters"
        >
          Apply Filters
        </Button>
      </div>
    </div>
  );
}
