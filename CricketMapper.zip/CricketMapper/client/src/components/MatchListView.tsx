import { Card, CardContent } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { MapPin, Clock } from "lucide-react";
import MatchStatusBadge, { type MatchStatus } from "./MatchStatusBadge";
import type { MatchData } from "./MatchPopupCard";

interface MatchListViewProps {
  matches: MatchData[];
  onMatchClick?: (matchId: string) => void;
}

export default function MatchListView({ matches, onMatchClick }: MatchListViewProps) {
  const getStatusColor = (status: MatchStatus) => {
    switch (status) {
      case "live":
        return "border-l-status-online";
      case "upcoming":
        return "border-l-status-away";
      case "completed":
        return "border-l-muted";
      default:
        return "border-l-border";
    }
  };

  return (
    <ScrollArea className="h-full">
      <div className="p-4 space-y-3">
        {matches.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <p>No matches found</p>
            <p className="text-sm mt-2">Try adjusting your filters</p>
          </div>
        ) : (
          matches.map((match) => (
            <Card
              key={match.id}
              className={`border-l-4 ${getStatusColor(match.status)} cursor-pointer hover-elevate active-elevate-2`}
              onClick={() => {
                console.log('Match clicked:', match.id);
                onMatchClick?.(match.id);
              }}
              data-testid={`card-list-match-${match.id}`}
            >
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="flex-1">
                    <div className="text-xs text-muted-foreground mb-1">
                      {match.league}
                    </div>
                    <MatchStatusBadge status={match.status} />
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {match.matchFormat}
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="font-semibold">{match.teamA}</div>
                    <div className="font-mono font-bold text-lg">{match.scoreA}</div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="font-semibold">{match.teamB}</div>
                    <div className="font-mono font-bold text-lg">{match.scoreB}</div>
                  </div>
                </div>

                {match.overs && (
                  <div className="text-xs text-muted-foreground mt-2">
                    {match.overs}
                  </div>
                )}

                <div className="flex items-center gap-4 mt-3 pt-3 border-t text-xs text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <MapPin className="w-3 h-3" />
                    <span>{match.venue}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    <span>{match.startTime}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </ScrollArea>
  );
}
