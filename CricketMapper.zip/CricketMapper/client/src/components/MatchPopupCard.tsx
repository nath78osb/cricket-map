import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MapPin, Calendar, Clock, Users, ExternalLink } from "lucide-react";
import MatchStatusBadge, { type MatchStatus } from "./MatchStatusBadge";

export interface MatchData {
  id: string;
  teamA: string;
  teamB: string;
  scoreA: string;
  scoreB: string;
  venue: string;
  league: string;
  matchFormat: string;
  status: MatchStatus;
  startTime: string;
  overs?: string;
}

interface MatchPopupCardProps {
  match: MatchData;
  onClose?: () => void;
}

export default function MatchPopupCard({ match, onClose }: MatchPopupCardProps) {
  return (
    <Card className="w-full max-w-[420px] rounded-2xl shadow-2xl" data-testid={`card-match-${match.id}`}>
      <CardHeader className="pb-4">
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1">
            <Badge variant="outline" className="mb-2 text-xs">
              {match.league}
            </Badge>
            <div className="flex items-center gap-2 flex-wrap">
              <MatchStatusBadge status={match.status} />
              <Badge variant="secondary" className="text-xs">
                {match.matchFormat}
              </Badge>
            </div>
          </div>
          {onClose && (
            <Button
              size="icon"
              variant="ghost"
              onClick={onClose}
              data-testid="button-close-popup"
              className="h-8 w-8"
            >
              ×
            </Button>
          )}
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold" data-testid="text-team-a">
              {match.teamA}
            </h3>
            <div className="text-3xl font-bold font-mono" data-testid="text-score-a">
              {match.scoreA}
            </div>
          </div>
          
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold" data-testid="text-team-b">
              {match.teamB}
            </h3>
            <div className="text-3xl font-bold font-mono" data-testid="text-score-b">
              {match.scoreB}
            </div>
          </div>
        </div>

        {match.overs && (
          <div className="text-sm text-muted-foreground" data-testid="text-overs">
            {match.overs}
          </div>
        )}

        <div className="grid grid-cols-2 gap-2 pt-2 border-t">
          <div className="flex items-start gap-2 text-sm">
            <MapPin className="w-4 h-4 mt-0.5 text-muted-foreground shrink-0" />
            <span className="text-muted-foreground" data-testid="text-venue">
              {match.venue}
            </span>
          </div>
          <div className="flex items-start gap-2 text-sm">
            <Clock className="w-4 h-4 mt-0.5 text-muted-foreground shrink-0" />
            <span className="text-muted-foreground" data-testid="text-time">
              {match.startTime}
            </span>
          </div>
        </div>

        <Button
          variant="outline"
          className="w-full"
          data-testid="button-view-scorecard"
          onClick={() => console.log('View scorecard:', match.id)}
        >
          <ExternalLink className="w-4 h-4 mr-2" />
          View Full Scorecard
        </Button>
      </CardContent>
    </Card>
  );
}
