import { Button } from "@/components/ui/button";
import { Menu, Map as MapIcon, List } from "lucide-react";

interface MapHeaderProps {
  onMenuClick?: () => void;
  viewMode?: "map" | "list";
  onViewModeChange?: (mode: "map" | "list") => void;
}

export default function MapHeader({ 
  onMenuClick, 
  viewMode = "map",
  onViewModeChange 
}: MapHeaderProps) {
  return (
    <header className="h-16 border-b bg-background sticky top-0 z-50 px-4 flex items-center justify-between">
      <div className="flex items-center gap-3">
        <Button
          size="icon"
          variant="ghost"
          onClick={onMenuClick}
          data-testid="button-menu"
          className="md:hidden"
        >
          <Menu className="w-5 h-5" />
        </Button>
        
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-md bg-primary flex items-center justify-center">
            <MapIcon className="w-5 h-5 text-primary-foreground" />
          </div>
          <h1 className="text-lg font-bold">Cricket Map</h1>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <div className="hidden sm:flex items-center gap-1 p-1 bg-muted rounded-md">
          <Button
            size="sm"
            variant={viewMode === "map" ? "secondary" : "ghost"}
            onClick={() => onViewModeChange?.("map")}
            data-testid="button-view-map"
            className="h-8"
          >
            <MapIcon className="w-4 h-4 mr-2" />
            Map
          </Button>
          <Button
            size="sm"
            variant={viewMode === "list" ? "secondary" : "ghost"}
            onClick={() => onViewModeChange?.("list")}
            data-testid="button-view-list"
            className="h-8"
          >
            <List className="w-4 h-4 mr-2" />
            List
          </Button>
        </div>
      </div>
    </header>
  );
}
