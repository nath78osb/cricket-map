import { useEffect, useState } from "react";
import { MapContainer, TileLayer, Marker, Popup, useMap } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import MatchPopupCard, { type MatchData } from "./MatchPopupCard";
import { type MatchStatus } from "./MatchStatusBadge";

delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
});

interface MatchLocation extends MatchData {
  lat: number;
  lng: number;
}

interface CricketMapProps {
  matches: MatchLocation[];
  center?: [number, number];
  zoom?: number;
}

function createCustomIcon(status: MatchStatus) {
  const colors = {
    live: "#22c55e",
    upcoming: "#f59e0b",
    completed: "#9ca3af",
  };

  const color = colors[status];
  
  return L.divIcon({
    className: "custom-marker",
    html: `
      <div style="
        background: ${color};
        width: 24px;
        height: 24px;
        border-radius: 50% 50% 50% 0;
        transform: rotate(-45deg);
        border: 2px solid white;
        box-shadow: 0 2px 4px rgba(0,0,0,0.2);
        ${status === 'live' ? 'animation: pulse 2s infinite;' : ''}
      ">
        <div style="
          width: 8px;
          height: 8px;
          background: white;
          border-radius: 50%;
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
        "></div>
      </div>
    `,
    iconSize: [24, 24],
    iconAnchor: [12, 24],
    popupAnchor: [0, -24],
  });
}

export default function CricketMap({ 
  matches, 
  center = [20, 0],
  zoom = 2 
}: CricketMapProps) {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    
    const style = document.createElement('style');
    style.textContent = `
      @keyframes pulse {
        0%, 100% { opacity: 1; transform: rotate(-45deg) scale(1); }
        50% { opacity: 0.7; transform: rotate(-45deg) scale(1.1); }
      }
      .leaflet-popup-content-wrapper {
        padding: 0;
        border-radius: 1rem;
        overflow: hidden;
      }
      .leaflet-popup-content {
        margin: 0;
      }
      .leaflet-popup-tip {
        display: none;
      }
    `;
    document.head.appendChild(style);

    return () => {
      document.head.removeChild(style);
    };
  }, []);

  if (!mounted) {
    return (
      <div className="w-full h-full bg-muted animate-pulse flex items-center justify-center text-muted-foreground">
        Loading map...
      </div>
    );
  }

  return (
    <MapContainer
      center={center}
      zoom={zoom}
      style={{ height: "100%", width: "100%" }}
      className="z-0"
    >
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      
      {matches.map((match) => (
        <Marker
          key={match.id}
          position={[match.lat, match.lng]}
          icon={createCustomIcon(match.status)}
        >
          <Popup className="custom-popup" maxWidth={440}>
            <MatchPopupCard match={match} />
          </Popup>
        </Marker>
      ))}
    </MapContainer>
  );
}
