import MatchPopupCard from "../MatchPopupCard";

export default function MatchPopupCardExample() {
  const mockMatch = {
    id: "1",
    teamA: "Mumbai Indians",
    teamB: "Chennai Super Kings",
    scoreA: "185-6",
    scoreB: "142-7",
    venue: "Wankhede Stadium, Mumbai",
    league: "IPL 2024",
    matchFormat: "Limited Overs",
    status: "live" as const,
    startTime: "19:30 IST",
    overs: "(19.4 ov, target 186)",
  };

  return (
    <div className="p-8 bg-background flex items-center justify-center min-h-screen">
      <MatchPopupCard match={mockMatch} onClose={() => console.log('Close')} />
    </div>
  );
}
