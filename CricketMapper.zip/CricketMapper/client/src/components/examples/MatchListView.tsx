import MatchListView from "../MatchListView";

export default function MatchListViewExample() {
  const mockMatches = [
    {
      id: "1",
      teamA: "Mumbai Indians",
      teamB: "Chennai Super Kings",
      scoreA: "185-6",
      scoreB: "142-7",
      venue: "Wankhede Stadium",
      league: "IPL 2024",
      matchFormat: "T20",
      status: "live" as const,
      startTime: "19:30 IST",
      overs: "(19.4 ov, target 186)",
    },
    {
      id: "2",
      teamA: "England",
      teamB: "Australia",
      scoreA: "425-8 dec",
      scoreB: "312-4",
      venue: "Lord's Cricket Ground",
      league: "Ashes 2024",
      matchFormat: "Test Match",
      status: "live" as const,
      startTime: "11:00 GMT",
      overs: "Day 2, Session 2",
    },
    {
      id: "3",
      teamA: "Sydney Sixers",
      teamB: "Melbourne Stars",
      scoreA: "162-5",
      scoreB: "158-9",
      venue: "SCG, Sydney",
      league: "BBL",
      matchFormat: "T20",
      status: "completed" as const,
      startTime: "15:00 AEDT",
    },
  ];

  return (
    <div className="h-screen bg-background">
      <MatchListView matches={mockMatches} />
    </div>
  );
}
