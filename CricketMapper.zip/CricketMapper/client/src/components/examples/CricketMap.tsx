import CricketMap from "../CricketMap";

export default function CricketMapExample() {
  const mockMatches = [
    {
      id: "1",
      teamA: "Mumbai Indians",
      teamB: "Chennai Super Kings",
      scoreA: "185-6",
      scoreB: "142-7",
      venue: "Wankhede Stadium, Mumbai",
      league: "IPL 2024",
      matchFormat: "Limited Overs",
      status: "live" as const,
      startTime: "19:30 IST",
      overs: "(19.4 ov, target 186)",
      lat: 18.9388,
      lng: 72.8258,
    },
    {
      id: "2",
      teamA: "England",
      teamB: "Australia",
      scoreA: "425-8 dec",
      scoreB: "312-4",
      venue: "Lord's Cricket Ground, London",
      league: "Ashes 2024",
      matchFormat: "Test Match",
      status: "live" as const,
      startTime: "11:00 GMT",
      overs: "Day 2, Session 2",
      lat: 51.5294,
      lng: -0.1727,
    },
    {
      id: "3",
      teamA: "Sydney Sixers",
      teamB: "Melbourne Stars",
      scoreA: "162-5",
      scoreB: "158-9",
      venue: "SCG, Sydney",
      league: "Big Bash League",
      matchFormat: "T20",
      status: "completed" as const,
      startTime: "15:00 AEDT",
      lat: -33.8915,
      lng: 151.2246,
    },
    {
      id: "4",
      teamA: "Yorkshire",
      teamB: "Lancashire",
      scoreA: "-",
      scoreB: "-",
      venue: "Headingley, Leeds",
      league: "County Championship",
      matchFormat: "First Class",
      status: "upcoming" as const,
      startTime: "Tomorrow, 10:30 GMT",
      lat: 53.8175,
      lng: -1.5822,
    },
  ];

  return (
    <div className="h-screen w-full">
      <CricketMap matches={mockMatches} center={[20, 20]} zoom={2} />
    </div>
  );
}
