import FilterPanel from "../FilterPanel";

export default function FilterPanelExample() {
  return (
    <div className="h-screen bg-background">
      <FilterPanel
        onFilterChange={(filters) => console.log('Filters changed:', filters)}
      />
    </div>
  );
}
