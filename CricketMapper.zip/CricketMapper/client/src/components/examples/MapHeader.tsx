import { useState } from "react";
import MapHeader from "../MapHeader";

export default function MapHeaderExample() {
  const [viewMode, setViewMode] = useState<"map" | "list">("map");

  return (
    <div className="bg-background">
      <MapHeader
        onMenuClick={() => console.log('Menu clicked')}
        viewMode={viewMode}
        onViewModeChange={setViewMode}
      />
    </div>
  );
}
