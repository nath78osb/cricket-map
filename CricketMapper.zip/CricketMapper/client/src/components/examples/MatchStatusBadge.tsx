import MatchStatusBadge from "../MatchStatusBadge";

export default function MatchStatusBadgeExample() {
  return (
    <div className="flex gap-4 p-8 bg-background">
      <MatchStatusBadge status="live" />
      <MatchStatusBadge status="upcoming" />
      <MatchStatusBadge status="completed" />
    </div>
  );
}
