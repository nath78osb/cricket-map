import { Badge } from "@/components/ui/badge";
import { Circle } from "lucide-react";

export type MatchStatus = "live" | "upcoming" | "completed";

interface MatchStatusBadgeProps {
  status: MatchStatus;
  className?: string;
}

export default function MatchStatusBadge({ status, className }: MatchStatusBadgeProps) {
  const statusConfig = {
    live: {
      label: "LIVE",
      variant: "default" as const,
      showPulse: true,
      bgColor: "bg-status-online",
    },
    upcoming: {
      label: "UPCOMING",
      variant: "secondary" as const,
      showPulse: false,
      bgColor: "bg-status-away",
    },
    completed: {
      label: "COMPLETED",
      variant: "secondary" as const,
      showPulse: false,
      bgColor: "bg-muted",
    },
  };

  const config = statusConfig[status];

  return (
    <Badge
      variant={config.variant}
      className={className}
      data-testid={`badge-status-${status}`}
    >
      {config.showPulse && (
        <Circle className="w-2 h-2 mr-1 fill-current animate-pulse" />
      )}
      {config.label}
    </Badge>
  );
}
